# set 'r', otherwise less breaks UTF-8 chars without UTF-8 locale
export SYSTEMD_LESS="FrSXMK"
