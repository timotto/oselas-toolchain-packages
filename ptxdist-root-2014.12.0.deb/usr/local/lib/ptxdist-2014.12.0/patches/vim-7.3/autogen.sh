#!/bin/bash

cd src &&
autoconf -o auto/configure
