
./autogen.sh

