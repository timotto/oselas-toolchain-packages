#!/bin/sh

autoconf -I build/aclocal/

