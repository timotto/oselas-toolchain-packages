#!/bin/sh

export ACLOCAL_FLAGS="-I m4"

`dirname $0`/autogen-generic.sh

