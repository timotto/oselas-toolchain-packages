#include <stdio.h>

int fish(void)
{
	printf("hello fish!\n");
	return 0;
}

