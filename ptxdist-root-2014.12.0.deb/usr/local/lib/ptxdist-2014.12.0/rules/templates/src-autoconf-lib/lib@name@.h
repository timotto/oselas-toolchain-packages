/*
 * (C) Copyright <year> <your name> <your mail address>
 *
 * <define the license of the file or refer to the main COPYING file>
 */

extern int @name@_library_globally_visible_function(void);
