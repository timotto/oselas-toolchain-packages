#include <stdio.h>

int main(void)
{
	printf("hello fish!\n");
	return 0;
}

