#!/bin/sh

exec ./autogen.sh
