#!/bin/sh

cd Src && `dirname $0`/autogen-generic.sh

