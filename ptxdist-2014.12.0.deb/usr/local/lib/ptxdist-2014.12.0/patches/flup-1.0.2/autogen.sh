#!/bin/bash

cp patches/setuptools-0.6c11-py2.7.egg .

