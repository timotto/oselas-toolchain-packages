#!/bin/sh

./autogen.sh --help

