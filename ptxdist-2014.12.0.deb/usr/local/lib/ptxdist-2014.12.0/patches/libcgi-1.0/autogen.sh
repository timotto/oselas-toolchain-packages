#!/bin/sh

autoconf

