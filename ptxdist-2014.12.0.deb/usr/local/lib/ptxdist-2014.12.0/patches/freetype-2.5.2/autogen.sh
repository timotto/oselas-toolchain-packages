#!/bin/sh

cd builds/unix &&
autoconf
