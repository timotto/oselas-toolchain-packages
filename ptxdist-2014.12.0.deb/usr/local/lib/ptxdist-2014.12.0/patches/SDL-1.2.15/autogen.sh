#!/bin/sh

./autogen.sh

