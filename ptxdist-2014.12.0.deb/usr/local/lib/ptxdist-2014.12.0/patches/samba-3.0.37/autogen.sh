#!/bin/bash

cd source && ./autogen.sh

