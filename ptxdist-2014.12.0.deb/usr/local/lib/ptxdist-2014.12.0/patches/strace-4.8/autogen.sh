#!/bin/bash

chmod +x git-version-gen
./patches/generic-autogen.sh
